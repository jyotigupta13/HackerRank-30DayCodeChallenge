import java.util.*;
public class StringPalindrom {

	public static void main(String[] args) {
		String name="";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string: ");
		String s=sc.nextLine();
		for(int i=s.length()-1;i>=0;i--){
			name=name+s.charAt(i);
		}
		if(s.compareTo(name)==0){
			System.out.println("palindrom");
		}
		else{
			System.out.println("not palindrom");
		}
		
	}

}
