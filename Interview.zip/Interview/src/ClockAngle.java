import java.util.*;
class ClockAngle{
  
  public static int findAngle(int hour, int min)
	{
		// find position of hour's hand
		int h = (hour * 360) / 12 + (min * 360) / (12 * 60);

		// find position of minute's hand
		int m = (min * 360) / (60);

		// calculate the angle difference
		int angle = Math.abs(h - m);

		// consider shorter angle and return it
		if (angle > 180) {
			angle = 360 - angle;
		}

		return angle;
	}

  public static void main(String ar[]){
    Scanner sc=new Scanner(System.in);
    int earthRotation = sc.nextInt();
    double longitude = sc.nextDouble();
    
    Double time = (earthRotation/360)*longitude;
    
    String Time = Double.toString(time);
    String Hour=Time.split(":")[0];
    String Minute=Time.split(":")[1];
    //If you want to use Hour and Minute for calculation purposes:
    int hour=Integer.parseInt(Hour);
    int minute=Integer.parseInt(Minute);
    
    System.out.print(findAngle(hour, minute));
  }
}