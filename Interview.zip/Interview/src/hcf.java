import java.util.Scanner;
public class hcf {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int hcf=1;
   Scanner sc=new Scanner(System.in);
  int a= sc.nextInt();
   int b=sc.nextInt();
   for(int i=2;i<=a && i<=b; i++){
	   if(a%i==0 && b%i==0){
		   hcf=i;
		   break;
	   }
   }
   System.out.println(hcf);
	}

}
