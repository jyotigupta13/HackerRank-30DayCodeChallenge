import java.util.*;
public class Armstrong {


	public static void main(String[] args) {
		int i;
		double num=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no :");
		int n=sc.nextInt();
		int temp=n;
		while(n>0){
			i=n%10;
			num=num+Math.pow(i,3);
			n=n/10;
		}
		if(temp==num){
			System.out.println("armstrong");
		}
		else{
			System.out.println("not armstrong");
		}
	}

}
