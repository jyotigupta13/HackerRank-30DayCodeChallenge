import java.util.Scanner;
public class Lcm {
static int lcm=0;
	static int lcm(int m,int n){
     	lcm=m>n?m:n;
        while(true){
     	if(lcm%m==0 && lcm%n==0){
     	return lcm;	
     	}
         else 
     	 lcm++;
        }
		
     }

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();	
        int b=sc.nextInt();
        lcm(a,b);
        System.out.println(lcm);
       
	}

	

}
