import java.util.*;
public class NoPalindrom{
	
	public static void main(String[] args) {
		int sum=0,i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no: ");
		int n=sc.nextInt();
		int temp=n;
		while(n>0){
			i=n%10;
			sum=sum*10+i;
			n=n/10;
			
		}
		if(temp==sum){
			System.out.println("palindrom");
		}
		else{
			System.out.println("not palindrom");
		}

	}

}
