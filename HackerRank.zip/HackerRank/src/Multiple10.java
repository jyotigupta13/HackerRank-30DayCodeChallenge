import java.util.Scanner;
public class Multiple10 {
	public static void main(String[] ar){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter value N : ");
     int N = sc.nextInt();
    // sc.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");
     for(int i=1;i<=10;i++){
     int result=N*i;
    System.out.println(N + " x " + i + " = " + result);
 }
	}
}
