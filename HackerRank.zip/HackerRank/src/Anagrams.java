import java.util.Arrays;
import java.util.Scanner;
public class Anagrams {
  boolean m1(String A,String B){
	  boolean f=false;
	   A=A.toLowerCase();
	   B=B.toLowerCase();
	  // char[] c=A.toCharArray();
	   
	   String smallest=A.substring(0);
       for(int i=0;i<A.length();i++){
           if(smallest.compareTo(A.substring(i))>0){
               smallest=A.substring(i);
           }
       }
	   
	  // Arrays.sort(c);
	  // char[] d=B.toCharArray();
	  // Arrays.sort(d);
        String small=B.substring(0);
       for(int i=0;i<B.length();i++){
           if(small.compareTo(B.substring(i))>0){
               small=B.substring(i);
           }
       }
       
	   String x=new String(smallest);
	   String y=new String(small);
	   if(x.equals(y)){
		   f=true;
	   }
	  return f;
   }
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String A=sc.next();
		String B=sc.next();
		Anagrams an=new Anagrams();
		boolean output=an.m1(A,B);
		System.out.println(output ? "Anagram" : "Not Anagram");

	}

}
