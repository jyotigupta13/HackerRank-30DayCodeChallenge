/*
    Sample Input
         He is a very very good boy, isn't he?
         
    Sample Output
  10
  He
  is
  a
  very
  very
  good
  boy
  isn
  t
  he
*/
import java.util.*;
public class ArrayLists {

	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		if (!sc.hasNext()){
            System.out.println(0);
        }
		else {
		String s=sc.nextLine();
		String[] a=s.trim().split("[ @;',.:?]+");
		ArrayList<String> str=new ArrayList<String>(Arrays.asList(a));
		int strs=str.size();
		System.out.println(strs);
		for(String op : str){
			System.out.println(op);
		  }
        }
	}

}
