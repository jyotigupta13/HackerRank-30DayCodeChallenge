import java.util.*;
import java.util.Arrays;
import java.util.Scanner;
public class Solution6 {

	
	public static void main(String[] args) {
		int count=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string : ");
		String s=sc.nextLine();
		for(int i=0;i<s.length();i++){
			if(s.charAt(i)==' ' && s.charAt(i+1)!=' '){
				count=++count;
				
			}
		}
		
		System.out.println(count);
		String[] a=s.trim().split(" [@.';:,]+");
		ArrayList<String> output=new ArrayList<String>(Arrays.asList(a));
		for(String string : output){
			System.out.println(string);
		}

	}

}
