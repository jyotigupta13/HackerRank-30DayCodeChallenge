import java.util.Scanner;
public class NextIntLine {

	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter integer : ");
		int i=sc.nextInt();
		System.out.println("Enter double : ");
		double d=sc.nextDouble();
		System.out.println("Enter string : ");
		/*After Integer it can not take immidiatly an string because First nextLine() check
		the integer next value in a quaue form. So we need to write again nextLine()for take
		input value of string */
		
	    String s1=sc.nextLine();
	    String s=sc.nextLine();
		System.out.println(s);
		System.out.println(d);
		System.out.println(i);

	}

}
