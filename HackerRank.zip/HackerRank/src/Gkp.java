
class Ltbp {
	
		{
			System.out.println("tnis is 1st parent instance block");
		}
		{
			System.out.println("this is 2nd parent instance block");
		}
		static 
		{
			System.out.println("this is 1st parent static block");
		}
		static
		{
			System.out.println("2nd parent static block");
		}
		Ltbp(int a,char c){
			System.out.println("this is parent 2nd argument constructor");
		}
		Ltbp()
		{
			System.out.println("this is parent 0 arg constructor");
		}
		void m1()
		{
			System.out.println("this is parent m1");
		}
		
	}
	class Gkp extends Ltbp{
		{
			System.out.println("this is 1st child instance block");
		}
		static
		{
			System.out.println("child static block");
		}
		Gkp(int a)
		{
			this();
			System.out.println("this is child 1 arg cons");
		}
		Gkp()
		{
			//super()
			System.out.println("this is child 0 arg constructor");
		}
		void m1(){
			System.out.println("this is child m1");
			super.m1();
		}
	
	public static void main(String[] args) {
		
		Ltbp t= new Ltbp();
		t.m1();
		Gkp g=new Gkp();
		g.m1();
	
	}

}
