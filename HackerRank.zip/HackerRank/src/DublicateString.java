import java.util.Scanner;
public class DublicateString {

	
	public static void main(String[] args) {
		int i,j;
		Scanner sc = new Scanner(System.in);
		String S = sc.next();
		
		char[] input = S.toCharArray();
		
		

	}

}
