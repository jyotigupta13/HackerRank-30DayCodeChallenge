/*
    Sample Input 0
      welcometojava
      3
  
    Sample Output 0
      ava
      wel
 */
import java.util.Scanner; 
public class Soluton5 {

	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string value : ");
		String s = sc.next();
		int k = sc.nextInt();
		
		int itr = s.length()-k;
		String smallest = s.substring(0,k);
		String largest = s.substring(0,k);
		for(int i=0;i<=itr;i++){
		if(smallest.compareTo(s.substring(i,i+k))>0){
		smallest = s.substring(i,i+k);
		}
		if(largest.compareTo(s.substring(i,i+k))<0){
		largest = s.substring(i,i+k);
		   }
		} 
		System.out.println("largest: " + largest + "\nsmallest: " + smallest);
	}

}
