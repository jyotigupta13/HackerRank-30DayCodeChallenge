   	import java.io.*;
	import java.util.*;

	public class Solution7 {

	    public static void main(String[] args) {
	        Scanner sc=new Scanner(System.in);
	        int a,b,c;
	        try{
	        a=sc.nextInt();
	        b=sc.nextInt();
	        
	            c=a/b;
	            System.out.println(c);
	        }
	         catch(InputMismatchException e){
	            System.out.println(e);
	        }
	        catch(ArithmeticException e){
	            System.out.println(e);
	        }
	        catch(Exception e){
	            System.out.println(e);
	        }
	       
	        
	        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
	    }
	}
